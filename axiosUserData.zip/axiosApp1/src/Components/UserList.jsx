import React, { useEffect, useState } from 'react';
import api from "./api";

const UserList = () => {

    const[users, setUser]= useState([]);
    const[loading, setLoading] = useState(true);
    const[error, setError] = useState(null);

    useEffect(()=>
    {
        api.get("/users") .then((response)=>{
            setUser(response.data);
            setLoading(false);
        })
        .catch((error)=>{
            setError(error.message);
            setLoading(false)
        })
    }, [])


    if(loading) 
        return
    (<p>Loading....</p>)

    if(error)
        return
    (<p>Error {error} </p>)

  return (
    
    <>
    <ul>
        {users.map((user)=>
                (
                <li key={user.id}>{user.name}, {user.email}</li>
                )
            )}
    </ul>
    </>
  )
}

export default UserList